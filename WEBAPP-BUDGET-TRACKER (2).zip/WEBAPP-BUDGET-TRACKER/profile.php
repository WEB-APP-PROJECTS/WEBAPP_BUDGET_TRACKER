<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>User Profile</title>


    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">


    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    
    <div class="profile-container" id ="profile-container">
        <div class="profile-header">
            <i class="fas fa-user-circle"></i>
            <h2>User Profile</h2>
        </div>

       

        <ul class="profile-menu">
            <li id="details-btn"><i class="fas fa-user"></i> Profile Details</li>
            <li id= "settings-btn"><i class="fas fa-cog"></i> Settings</li>
            <li id = "support-btn"><i class="fas fa-life-ring"></i> Support</li>
            <li class="logout" id="logout-btn"><i class="fas fa-sign-out-alt"></i> Log out</li>
        </ul>
    
    </div>
    

    <script src="profile-script.js"></script>


    <footer class="nav-bar">
  <a href="homepage.php" title="Home"><i class="fas fa-home"></i></a>
    <a href="Add_Transactions.php" title="Add Transaction"><i class="fas fa-plus-circle"></i></a>
    <a href="view-transactions.php" title="View Transactions"><i class="fas fa-receipt"></i></a>
    <a href="profile.php" title="User Profile"><i class="fas fa-user-circle"></i></a>
</footer>


</body>
</html>
